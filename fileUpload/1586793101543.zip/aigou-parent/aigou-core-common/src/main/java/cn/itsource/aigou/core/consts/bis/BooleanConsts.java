package cn.itsource.aigou.core.consts.bis;

import cn.itsource.aigou.core.consts.ConstName;

public interface BooleanConsts {
	@ConstName("否")
	public static byte NO  =  0;
	@ConstName("是")
	public static byte YES = 1;
}
