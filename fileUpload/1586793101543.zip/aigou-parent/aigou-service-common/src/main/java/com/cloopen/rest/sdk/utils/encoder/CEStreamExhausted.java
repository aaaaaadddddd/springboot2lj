package com.cloopen.rest.sdk.utils.encoder;

import java.io.IOException;

public class CEStreamExhausted extends IOException
{

}
