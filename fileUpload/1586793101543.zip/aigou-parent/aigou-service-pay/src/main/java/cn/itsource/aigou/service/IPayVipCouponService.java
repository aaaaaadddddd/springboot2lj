package cn.itsource.aigou.service;

import cn.itsource.aigou.core.common.base.IBaseService;
import cn.itsource.aigou.core.domain.PayVipCoupon;

public interface IPayVipCouponService extends IBaseService<PayVipCoupon> {
}
