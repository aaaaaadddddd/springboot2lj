package cn.itsource.aigou.service;

import cn.itsource.aigou.core.common.base.IBaseService;
import cn.itsource.aigou.core.domain.PayAccountFlow;

public interface IPayAccountFlowService extends IBaseService<PayAccountFlow> {
}
