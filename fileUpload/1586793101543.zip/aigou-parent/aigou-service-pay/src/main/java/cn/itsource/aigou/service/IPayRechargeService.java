package cn.itsource.aigou.service;

import cn.itsource.aigou.core.common.base.IBaseService;
import cn.itsource.aigou.core.domain.PayRecharge;

public interface IPayRechargeService extends IBaseService<PayRecharge> {
}
