package cn.itsource.aigou.facade.query;

import java.io.Serializable;

import cn.itsource.aigou.core.query.BaseQuery;

public class ProductTypeQuery extends BaseQuery implements Serializable{
	private static final long serialVersionUID = -3281167135201854658L;

}
