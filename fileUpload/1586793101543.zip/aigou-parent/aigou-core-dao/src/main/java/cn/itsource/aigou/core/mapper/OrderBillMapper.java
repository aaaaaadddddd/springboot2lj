package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.OrderBill;

public interface OrderBillMapper extends BaseMapper<OrderBill> {
}