package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.EmployeeRole;

public interface EmployeeRoleMapper extends BaseMapper<EmployeeRole> {
}