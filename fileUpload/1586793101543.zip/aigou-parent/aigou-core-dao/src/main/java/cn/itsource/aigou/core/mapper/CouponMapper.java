package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.Coupon;

public interface CouponMapper extends BaseMapper<Coupon> {
}