package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.PromotionScopeValue;

public interface PromotionScopeValueMapper extends BaseMapper<PromotionScopeValue> {
}