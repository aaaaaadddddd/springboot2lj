package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.VipBase;

public interface VipBaseMapper extends BaseMapper<VipBase> {
}