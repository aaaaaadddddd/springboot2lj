package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.AdArea;

public interface AdAreaMapper extends BaseMapper<AdArea> {
}