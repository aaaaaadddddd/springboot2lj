package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.ProductComment;

public interface ProductCommentMapper extends BaseMapper<ProductComment> {
}