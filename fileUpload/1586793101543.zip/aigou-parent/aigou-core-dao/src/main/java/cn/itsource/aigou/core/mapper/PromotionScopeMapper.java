package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.PromotionScope;

public interface PromotionScopeMapper extends BaseMapper<PromotionScope> {
}