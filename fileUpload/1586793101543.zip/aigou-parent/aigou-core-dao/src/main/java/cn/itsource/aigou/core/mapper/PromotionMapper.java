package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.Promotion;

public interface PromotionMapper extends BaseMapper<Promotion> {
}