package cn.itsource.aigou.core.mapper;

public interface BaseMapper<T> extends cn.itsource.aigou.core.common.base.BaseMapper<T> {
}
