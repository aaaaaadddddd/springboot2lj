package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.SeckillSku;

public interface SeckillSkuMapper extends BaseMapper<SeckillSku> {
}