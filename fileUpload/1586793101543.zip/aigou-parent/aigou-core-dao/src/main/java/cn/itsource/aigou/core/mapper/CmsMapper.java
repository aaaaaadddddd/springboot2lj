package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.Cms;

public interface CmsMapper extends BaseMapper<Cms> {
}