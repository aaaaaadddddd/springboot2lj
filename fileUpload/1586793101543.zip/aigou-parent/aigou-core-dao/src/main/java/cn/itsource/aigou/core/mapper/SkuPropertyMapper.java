package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.SkuProperty;

public interface SkuPropertyMapper extends BaseMapper<SkuProperty> {
}