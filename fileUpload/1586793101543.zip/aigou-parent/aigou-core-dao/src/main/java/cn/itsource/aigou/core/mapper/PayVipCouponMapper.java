package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.PayVipCoupon;

public interface PayVipCouponMapper extends BaseMapper<PayVipCoupon> {
}