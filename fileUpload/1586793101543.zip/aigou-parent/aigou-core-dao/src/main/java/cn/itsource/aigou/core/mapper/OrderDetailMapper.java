package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.OrderDetail;

public interface OrderDetailMapper extends BaseMapper<OrderDetail> {
}