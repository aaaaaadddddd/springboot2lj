package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.OrderReturn;

public interface OrderReturnMapper extends BaseMapper<OrderReturn> {
}