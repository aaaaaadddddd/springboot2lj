package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.SeckillResult;

public interface SeckillResultMapper extends BaseMapper<SeckillResult> {
}