package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.CouponInfo;

public interface CouponInfoMapper extends BaseMapper<CouponInfo> {
}