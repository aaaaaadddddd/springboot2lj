package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.VipGrowLog;

public interface VipGrowLogMapper extends BaseMapper<VipGrowLog> {
}