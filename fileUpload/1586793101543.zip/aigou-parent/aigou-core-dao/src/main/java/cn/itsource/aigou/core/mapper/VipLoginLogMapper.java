package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.VipLoginLog;

public interface VipLoginLogMapper extends BaseMapper<VipLoginLog> {
}