package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.Dictionary;

public interface DictionaryMapper extends BaseMapper<Dictionary> {
}