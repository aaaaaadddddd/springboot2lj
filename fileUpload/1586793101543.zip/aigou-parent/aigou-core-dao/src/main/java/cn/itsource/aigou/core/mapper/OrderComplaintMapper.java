package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.OrderComplaint;

public interface OrderComplaintMapper extends BaseMapper<OrderComplaint> {
}