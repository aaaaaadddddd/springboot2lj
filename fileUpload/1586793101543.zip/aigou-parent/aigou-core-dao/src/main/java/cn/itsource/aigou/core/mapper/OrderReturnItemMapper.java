package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.OrderReturnItem;

public interface OrderReturnItemMapper extends BaseMapper<OrderReturnItem> {
}