package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.Employee;

public interface EmployeeMapper extends BaseMapper<Employee> {
}