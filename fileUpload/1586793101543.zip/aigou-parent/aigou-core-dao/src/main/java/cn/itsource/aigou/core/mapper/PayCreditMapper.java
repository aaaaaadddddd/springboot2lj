package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.PayCredit;

public interface PayCreditMapper extends BaseMapper<PayCredit> {
}