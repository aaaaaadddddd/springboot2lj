package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.VipRealinfo;

public interface VipRealinfoMapper extends BaseMapper<VipRealinfo> {
}