package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.SmsLog;

public interface SmsLogMapper extends BaseMapper<SmsLog> {
}