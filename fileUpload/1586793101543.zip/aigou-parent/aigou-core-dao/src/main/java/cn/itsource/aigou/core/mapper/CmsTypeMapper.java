package cn.itsource.aigou.core.mapper;

import cn.itsource.aigou.core.domain.CmsType;

public interface CmsTypeMapper extends BaseMapper<CmsType> {
}